﻿namespace BibleApp.Models
{
    public class VerseModel
    {
        public int Id { get; set; }
        public int Book { get; set; }
        public int Chapter { get; set; }
        public int Verse { get; set; }
        public string Text { get; set; }

        public VerseModel()
        {
        }
        public VerseModel(int id, int book, int chapter, int verse, string text)
        {
            Id = id;
            Book = book;
            Chapter = chapter;
            Verse = verse;
            Text = text;
        }
    }
}
