﻿using BibleApp.Models;
using BibleApp.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace BibleApp.Controllers
{
    public class HomeController : Controller
    {
        List<VerseModel> verses = new List<VerseModel>();
        public IActionResult Index()
        {
            
            

            return View();
        }
        public IActionResult SearchBible(string search, string testament)
        {
            
            BibleVerseService verseService = new BibleVerseService();
            verses = verseService.getVerse();
            var versesFound = new List<VerseModel>();
            if(testament == "all")
            {
                foreach (VerseModel v in verses)
                {
                    if (v.Text.Contains(search))
                    {
                        versesFound.Add(v);
                    }
                }
            }
            else if(testament == "old")
            {
                foreach (VerseModel v in verses)
                {
                    if (v.Text.Contains(search) && v.Book <= 39)
                    {
                        versesFound.Add(v);
                    }
                }
            }
            else
            {
                foreach (VerseModel v in verses)
                {
                    if (v.Text.Contains(search) && v.Book > 39)
                    {
                        versesFound.Add(v);
                    }
                }
            }
            

            return View("SearchResults", versesFound);
        }
    }
}