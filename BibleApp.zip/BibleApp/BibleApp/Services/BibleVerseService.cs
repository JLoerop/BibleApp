﻿using BibleApp.Models;

namespace BibleApp.Services
{
    public class BibleVerseService
    {
        BibleVerseDAO verseDAO = new BibleVerseDAO();
        public List<VerseModel> getVerse()
        {
            return verseDAO.getVerses();
        }
    }
}
