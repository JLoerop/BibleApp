﻿using BibleApp.Models;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace BibleApp.Services
{
    public class BibleVerseDAO
    {
        String connectionString = "datasource=localhost;port=3306;username=root;password=root;database=bible";
        public List<VerseModel> getVerses()
        {
            List<VerseModel> verses = new List<VerseModel>();

            string sqlStatement = "SELECT * FROM `t_kjv`";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(sqlStatement, connection);
                try{
                    connection.Open();
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        UInt32 uint32Value = (uint)reader[0];
                        Int32 int32Value = (Int32)Convert.ChangeType(uint32Value, typeof(Int32));
                        verses.Add(new VerseModel(int32Value, (int)reader[1], (int)reader[2], (int)reader[3], (string)reader[4]));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
                
            }
            return verses;
        }
    }
}
